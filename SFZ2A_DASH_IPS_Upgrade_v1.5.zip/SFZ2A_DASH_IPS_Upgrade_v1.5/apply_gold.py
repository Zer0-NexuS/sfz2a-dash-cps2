#!/usr/bin/env python3
"""Upgrade an unpacked stock sfz2ald ROM ZIP to GOLD Test 15. Python 3.8+."""

import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile


ROOT = Path(__file__).resolve().parent
MAX_IPS_SIZE = 0x1000000


class UpgradeError(Exception):
    pass


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def apply_ips(source, patch):
    """Apply classic IPS, including RLE and the optional final-size extension."""
    if not patch.startswith(b"PATCH"):
        raise UpgradeError("Invalid IPS header.")
    output = bytearray(source)
    pos = 5
    while True:
        if pos + 3 > len(patch):
            raise UpgradeError("Incomplete IPS record or missing EOF.")
        marker = patch[pos:pos + 3]
        pos += 3
        if marker == b"EOF":
            tail = patch[pos:]
            if len(tail) == 3:
                size = int.from_bytes(tail, "big")
                del output[size:]
                if size > len(output):
                    output.extend(b"\0" * (size - len(output)))
            elif tail:
                raise UpgradeError("Unexpected bytes after IPS EOF.")
            return bytes(output)
        offset = int.from_bytes(marker, "big")
        if pos + 2 > len(patch):
            raise UpgradeError("Incomplete IPS record length.")
        length = int.from_bytes(patch[pos:pos + 2], "big")
        pos += 2
        if length:
            if pos + length > len(patch):
                raise UpgradeError("Incomplete IPS data.")
            data = patch[pos:pos + length]
            pos += length
        else:
            if pos + 3 > len(patch):
                raise UpgradeError("Incomplete IPS RLE record.")
            length = int.from_bytes(patch[pos:pos + 2], "big")
            if not length:
                raise UpgradeError("Empty IPS RLE record.")
            data = patch[pos + 2:pos + 3] * length
            pos += 3
        end = offset + length
        if end > MAX_IPS_SIZE:
            raise UpgradeError("IPS output exceeds this package's 16 MiB limit.")
        if end > len(output):
            output.extend(b"\0" * (end - len(output)))
        output[offset:end] = data


def checked_patch(root, spec):
    path = root / spec["file"]
    data = path.read_bytes()
    if len(data) != spec["bytes"] or sha256(data) != spec["sha256"]:
        raise UpgradeError("Patch checksum mismatch: " + spec["file"])
    return data


def load_stock(source, manifest):
    expected = {r["name"].lower(): r for r in manifest["roms"]}
    found = {}
    with zipfile.ZipFile(source) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = info.filename.replace("\\", "/").rsplit("/", 1)[-1].lower()
            if name not in expected:
                continue
            if name in found:
                raise UpgradeError("Ambiguous input: duplicate ROM member " + name)
            record = expected[name]
            if info.file_size != record["stock"]["bytes"]:
                raise UpgradeError("Wrong size for " + name + "; this is not the supported stock set.")
            found[name] = archive.read(info)
    missing = sorted(set(expected) - set(found))
    if missing:
        raise UpgradeError("Missing ROM members: " + ", ".join(missing) +
                           ". Use a complete stock sfz2ald.zip, including shared ROMs and phoenix.key.")
    hashes = {name: sha256(data) for name, data in found.items()}
    if all(hashes[name] == r["gold"]["sha256"] for name, r in expected.items()):
        raise UpgradeError("This ZIP already contains GOLD Test 15. No patch was applied.")
    wrong = [name for name, r in expected.items() if hashes[name] != r["stock"]["sha256"]]
    if wrong:
        details = [name + " (got " + hashes[name] + ", expected " +
                   expected[name]["stock"]["sha256"] + ")" for name in wrong]
        raise UpgradeError("Unsupported or modified stock ROMs:\n  " + "\n  ".join(details))
    return {r["name"]: found[r["name"].lower()] for r in manifest["roms"]}


def build_member_zip(stock, manifest, root):
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for record in manifest["roms"]:
            data = stock[record["name"]]
            if record["patch"] is not None:
                data = apply_ips(data, checked_patch(root, record["patch"]))
            if len(data) != record["gold"]["bytes"] or sha256(data) != record["gold"]["sha256"]:
                raise UpgradeError("Patched ROM verification failed: " + record["name"])
            info = zipfile.ZipInfo(record["name"], tuple(manifest["zip_metadata"]["date_time"]))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = manifest["zip_metadata"]["create_system"]
            info.external_attr = manifest["zip_metadata"]["external_attr"]
            archive.writestr(info, data)
    return output.getvalue()


def verify_gold_zip(data, manifest):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        if len(names) != len(manifest["roms"]) or set(names) != {r["name"] for r in manifest["roms"]}:
            raise UpgradeError("Output ZIP has the wrong member list.")
        for record in manifest["roms"]:
            rom = archive.read(record["name"])
            if len(rom) != record["gold"]["bytes"] or sha256(rom) != record["gold"]["sha256"]:
                raise UpgradeError("Output ROM verification failed: " + record["name"])


def upgrade(source, output, root=ROOT):
    manifest = json.loads((root / "patch_manifest.json").read_text(encoding="utf-8"))
    source, output = Path(source).resolve(), Path(output).resolve()
    if source == output:
        raise UpgradeError("Choose a separate output path; the stock ZIP is preserved.")
    if output.exists():
        raise UpgradeError("Output already exists: " + str(output) + ". Choose a new path or move it first.")
    if not source.is_file():
        raise UpgradeError("Stock ZIP not found: " + str(source))
    stock = load_stock(source, manifest)
    print("Verified all 19 stock ROM members.")
    source_bytes = source.read_bytes() if source.stat().st_size == manifest["stock_zip"]["bytes"] else None
    if source_bytes is not None and sha256(source_bytes) == manifest["stock_zip"]["sha256"]:
        data = apply_ips(source_bytes, checked_patch(root, manifest["direct_zip_patch"]))
        if len(data) != manifest["gold_zip"]["bytes"] or sha256(data) != manifest["gold_zip"]["sha256"]:
            raise UpgradeError("Direct ZIP patch did not reproduce the released build.")
        route = "direct ZIP IPS"
    else:
        data = build_member_zip(stock, manifest, root)
        route = "per-ROM IPS (repacked stock ZIP)"
    verify_gold_zip(data, manifest)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation prevents replacing the stock or another existing build.
    with output.open("xb") as handle:
        try:
            handle.write(data)
        except BaseException:
            handle.close()
            output.unlink()
            raise
    print("Applied " + route + ".")
    print("Verified all 19 GOLD ROM members against Test 15.")
    print("Created: " + str(output))
    print("ZIP SHA-256: " + sha256(data))
    if sha256(data) != manifest["gold_zip"]["sha256"]:
        print("ZIP compression differs from the reference; all game ROM bytes match exactly.")
    print("Keep the output named sfz2ald.zip when loading it in your emulator.")
    return {"route": route, "sha256": sha256(data), "roms_verified": len(manifest["roms"])}


def main():
    parser = argparse.ArgumentParser(description="Upgrade stock sfz2ald.zip to GOLD Test 15; preserve the original.")
    parser.add_argument("stock", nargs="?", type=Path, default=ROOT / "sfz2ald.zip",
                        help="stock ZIP (default: sfz2ald.zip beside this script)")
    parser.add_argument("-o", "--output", type=Path, help="new ZIP path (default: GOLD/sfz2ald.zip beside the stock ZIP)")
    args = parser.parse_args()
    output = args.output or args.stock.resolve().parent / "GOLD" / "sfz2ald.zip"
    try:
        upgrade(args.stock, output)
    except (UpgradeError, OSError, ValueError, KeyError, RuntimeError, zipfile.BadZipFile) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
