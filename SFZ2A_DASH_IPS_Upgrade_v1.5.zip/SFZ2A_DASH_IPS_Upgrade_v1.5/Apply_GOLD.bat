@echo off
setlocal
where py >nul 2>nul
if not errorlevel 1 goto use_py
where python >nul 2>nul
if not errorlevel 1 goto use_python
echo Python 3.8 or newer is required for this helper.
echo Alternatively, apply the ZIP IPS with an IPS patcher as described in README.md.
pause
exit /b 1
:use_py
py -3 "%~dp0apply_gold.py" %*
goto finished
:use_python
python "%~dp0apply_gold.py" %*
:finished
set "gold_exit=%errorlevel%"
echo.
pause
exit /b %gold_exit%
