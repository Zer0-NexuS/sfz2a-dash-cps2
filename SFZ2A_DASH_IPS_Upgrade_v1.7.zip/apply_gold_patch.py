#!/usr/bin/env python3
"""Apply Gold Test 17 IPS patches to verified stock sfz2ald ROM members."""
from pathlib import Path
import hashlib,json,sys,zipfile
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def apply(old,p):
 if p[:5]!=b'PATCH':raise ValueError('Bad IPS signature')
 out=bytearray(old);q=5
 while p[q:q+3]!=b'EOF':
  at=int.from_bytes(p[q:q+3],'big');n=int.from_bytes(p[q+3:q+5],'big');q+=5
  if n:data=p[q:q+n];q+=n
  else:
   n=int.from_bytes(p[q:q+2],'big');data=p[q+2:q+3]*n;q+=3
  if at+n>len(out):out.extend(bytes(at+n-len(out)))
  out[at:at+n]=data
 q+=3
 if len(p)-q==3:
  n=int.from_bytes(p[q:],'big');out=out[:n]+bytes(max(0,n-len(out)))
 return bytes(out)
def main():
 if len(sys.argv)!=3:raise SystemExit('Usage: python3 apply_gold_patch.py stock/sfz2ald.zip gold/sfz2ald.zip')
 src=Path(sys.argv[1]);dst=Path(sys.argv[2]);m=json.loads((R/'patch_manifest.json').read_text())
 if dst.exists() or src.resolve()==dst.resolve():raise SystemExit('Choose a new output path; source/output will not be overwritten.')
 members={}
 with zipfile.ZipFile(src)as z:
  for row in m['members']:
   name=row['name'];b=z.read(name)
   if sha(b)!=row['base_sha256']:raise SystemExit('Wrong base ROM member: '+name)
   if 'patch' in row:b=apply(b,(R/row['patch']).read_bytes())
   if sha(b)!=row['target_sha256']:raise SystemExit('Patched member verification failed: '+name)
   members[name]=b
 dst.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(dst,'x',zipfile.ZIP_DEFLATED)as z:
  for name,b in members.items():
   info=zipfile.ZipInfo(name,date_time=(2026,9,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 if sha(dst.read_bytes())!=m['target_zip_sha256']:raise SystemExit('Member hashes match, but ZIP encoding differs from reference. See patch_manifest.json.')
 print('Verified Gold Test 17: '+str(dst))
if __name__=='__main__':main()
