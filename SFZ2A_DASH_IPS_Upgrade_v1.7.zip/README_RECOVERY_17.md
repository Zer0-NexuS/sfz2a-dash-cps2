# SFZ2A GOLD Cammy — Battle Test 17

Test 17 corrects the remaining confirmed Cammy integration gaps found in the recovered project. It restores the original Gold campaign relationships and replaces the custom reciprocal Rose/Bison encounters from Test 16.

## Play

Extract **sfz2ald.zip** from the release package and use that inner ZIP with the decrypted SFZ2A emulator driver. Keep its filename. Start from a fresh boot: old save states can restore an older program.

Highlight M. Bison, press Start twice, then confirm Cammy. Both players are supported. Boot selects USA and bypasses the Phoenix startup logo/region selector. The normal service/test menu remains available.

## What Test 17 corrects

- **CPU behavior:** Gold's four Cammy decision banks and character-specific callback now feed the native arcade AI interpreter. The callback preserves the interpreter's script cursor. Weighted probability arrays keep their byte order while script words are converted for the 68000.
- **Campaign order:** Both complete Cammy opponent-order tables now come from Gold, with 16 variants each. The unused arcade slot's old list incorrectly led to Chun-Li as the final opponent; the corrected normal route ends with Charlie and then Bison.
- **Original rival relationships:** Cammy's hidden rival is Rose, Rose's is Chun-Li, and Bison's is Charlie. Custom reciprocal Cammy scenes are removed from Rose and Bison's campaigns. Their ordinary final bosses remain Bison and Ryu, respectively.
- **Hooligan Combination:** The opponent-height row for a Cammy mirror match is remapped from Gold slot 30 to native slot 31. Head grab, leg/air grab, slide and failed-grab escape branches were exercised.
- **Psycho Streak:** Gold's projectile-type-5 collision row and column are installed. The unused arcade entries caused a reproducible CPU address exception when Psycho Streak encountered another projectile. The corrected clash against Ryu's Hadouken completes and returns Cammy to idle.
- **Attached hit effects:** Three Cammy-specific head/body effect-position tables are bound to Gold's data. The byte-coordinate array is preserved without incorrectly swapping its coordinate pairs.
- **Voice envelopes:** The shared donor bank's sample gain and attack/decay/sustain parameters are recovered and baked into the 14 used voice samples before conversion to QSound PCM. This improves the earlier full-sustain approximation.

The earlier vertical stage-strip repair, Gold movement and combat handlers, animation/collision/attack data, six costumes, character and presentation graphics, voices, story dialogue, ending, title and USA boot changes remain integrated.

## Story and ending

| Campaign | Hidden rival | Final opponent | Cammy-specific dialogue |
| --- | --- | --- | --- |
| Cammy | Rose | M. Bison | Gold's four Rose pages and four Bison pages |
| Rose | Chun-Li | M. Bison | None added to Rose's route |
| M. Bison | Charlie | Ryu | None added to Bison's route |

Cammy uses her Gold dialogue portrait. The compact source text cells retain all eight English pages, including pages longer than the native font object's ordinary capacity. Her Gold ending contains the original artwork and 17 narration objects, including the Psycho Limiter scene.

The corrected Cammy campaign reached Bison's conversation and battle through the ordinary arcade controller, then displayed the ending and proceeded into the credits. That run used controller input and HP-only assistance; it did not inject opponents, scene IDs, KO states or campaign progression. Hidden-rival qualification was not earned in that run. The Rose and Bison conversations were separately checked through controlled prebattle scene entry on both player sides.

## Sources and the CPS2 back-port

The target is the project's stock decrypted **sfz2ald.zip**. Cammy's primary donor is **Street Fighter Alpha Anthology — Alpha 2 Gold**, recovered from **Alpha_2_Gold_Extracted_Data.zip**.

| Source | Use |
| --- | --- |
| Gold **X_0526.dec** | Character records, MIPS move/AI handlers, animation, collision, attacks, movement, palettes, campaign orders, dialogue, ending logic and text |
| Gold **X_0527–X_0535** graphics resources | Character and presentation graphics used by the conversion; used banks and offsets are recorded in the source manifests |
| Anthology shared **X_0333** audio bank | Matched Cammy voice samples and sample parameters; recovered under the Alpha 3 Upper family-reference folder |
| Saturn **OPENING.BIN / OPENING.Z** and earlier recovery traces | Separate Gold title artwork and native UI positioning/recovery references |
| Stock decrypted arcade SFZ2A | Native 68000 game engine, rendering, collision processing, campaign controller and QSound playback |

The shared audio bank's folder name does **not** mean Cammy uses Alpha 3 fighting behavior. The title art's separate Saturn provenance is documented rather than attributed to Anthology.

PS2 MIPS instructions cannot execute on the CPS2's 68000. Relevant Gold handlers were disassembled, lifted and manually adapted to native Alpha 2 player objects, register conventions and engine calls, then assembled as 68000 routines. Data conversion changes byte order, relocates pointers and maps Gold character slot 30 to the project's native slot 31. Gold sprite layouts and tiles are converted for the CPS2 renderer, and voice audio is converted for QSound. This is a back-port into the arcade engine, not an embedded PS2 emulator or a wholesale conversion of every PS2 engine routine.

The inherited fight/auxiliary import contains **1,103 frames, 386 compositions, 5,853 tiles and 85 attack records**, plus separate UI, voice, dialogue and ending assets. The static audit checks all **1,041 core animation records**, including timing, collision and composition bindings. See `manifest.json`, `RECOVERY_INDEX_17.json` and the conversion scripts for offsets and fingerprints.

## Verification

Testing was limited to the changes and relevant integration risks, using the unmodified MAME 2010 core:

- Exact donor comparisons for all four AI banks, both campaign-order rows, rival assignments, type-5 projectile interactions, effect offsets, throw pairings, six costumes, movement and the 1,041 core animation records. All 434 program sections are checked for overlap; the graphics conversion passes a pixel round trip and leaves native stage graphics unchanged.
- Two 1,400-frame CPU runs check every active AI script cursor. Focused Hooligan branches, all three Psycho Streak strengths from both player sides, block/air/projectile interactions and ten throw/body-type cases exercise the added bindings.
- Four Cammy conversation runs check all 16 page/side combinations and return to the round controller.
- Six final-ROM Spin Drive Smasher cases cover all three strengths, both player sides and Gen's stage: damage, meter use, return to idle and valid afterimage frame/composition references pass. Selected captures were visually reviewed.
- HP-assisted Cammy, Rose and Bison campaigns reach their endings and credits. Cammy's final-ROM run verifies Bison and all 17 ending text objects.
- A clean rebuild and both IPS application paths must reproduce all 19 released ROM members and the exact ZIP fingerprint.

The reports record the actual ROM hash for each test. Earlier Test 17 move/AI, dialogue and Rose/Bison campaign checks were not silently relabeled as final-ROM reruns. The initial projectile-clash failure is retained as history and superseded by the successful final-ROM regression. `VALIDATION_17.json` indexes the evidence.

### What is still unproven

**The rare square in the blue Spin Drive trail on Gen's stage has not reproduced. Its cause is still unconfirmed; this release does not claim that particular defect is fixed.** The effect-offset correction is a separate verified integration repair.

Exact PS2 global reverb and sequencer note-off behavior are not reproduced or validated end to end. The sample envelopes are baked, and QSound uses resampled PCM; the previous pitch-compensated resampling of 156 original long one-shots remains. Exhaustive PS2 timing/AI parity and physical CPS2 hardware operation have not been established. Accordingly, this is a native arcade Gold back-port test build, not a substantiated claim of a “perfect” or bit-exact recreation of the entire PS2 game.

## Patch stock sfz2ald.zip

The separate IPS package contains a conventional ZIP-level IPS, member-level IPS files and a checksum-verifying helper. Recommended:

```bash
python3 apply_gold_patch.py stock/sfz2ald.zip gold/sfz2ald.zip
```

This accepts repacked stock archives with matching ROM members and writes a new output. The single `SFZ2A_GOLD_Test_17.ips` applies directly to the exact stock ZIP identified in `patch_manifest.json`; a differently compressed ZIP must use the helper. Both paths verify against the released ROM.

## Rebuild and recovery

The separate source checkpoint is self-contained: baseline ROM, donor resources, conversion scripts, native assembly, bundled m68k binutils, emulator and verification evidence are included.

```bash
bash REBUILD.sh
```

Output: **build17_rebuilt/sfz2ald.zip**. Requires Linux x86-64, Python 3, FFmpeg and a C compiler; Python packages are listed in `requirements-build.txt`. The active builder is `project_restore/SFZ2A_Cammy_Arcade_Checkpoint_09/arcade/tools/build_gold.py`.

Run `python3 analysis/verify_static17.py` for the source/data audit. The optional bounded runtime suites are `verify_moves17.py`, `verify_story_trail17.py` and `verify_campaign17.py`. Compile the campaign harness with:

```bash
cc -O2 -I project_restore/SFZ2A_Cammy_Arcade_Checkpoint_09/arcade/tools analysis/campaign_runner17.c -ldl -o mame17/campaign_runner
```

Historical generators are recovery material. Do not overwrite the manually adapted assembly with an obsolete draft generator. Historical Test 14–16 documentation describes those versions, not the current route choices.

Audio format research references: [VGMTrans SonyPS2 instrument parser](https://github.com/vgmtrans/vgmtrans/blob/master/src/main/formats/SonyPS2/SonyPS2InstrSet.cpp), [PS2SDK libsd definitions](https://github.com/ps2dev/ps2sdk/blob/master/common/include/libsd-common.h), and [PCSX2 SPU2 ADSR implementation](https://github.com/PCSX2/pcsx2/blob/master/pcsx2/SPU2/ADSR.cpp). The project's envelope converter is included in `analysis/gold_voice_envelope.py`.
