# Stock sfz2ald to GOLD Test 17

Recommended: extract this package, then run:

```
python3 apply_gold_patch.py stock/sfz2ald.zip gold/sfz2ald.zip
```

The script applies standard IPS patches to the individual ROM members. It accepts differently packed stock ZIPs when their ROM contents match, verifies every base and output member, and writes a new sfz2ald.zip. It never overwrites your source.

For a conventional IPS patcher, apply **SFZ2A_GOLD_Test_17.ips directly to the stock ZIP**, without extracting it. This standalone archive patch requires the exact source ZIP hash in patch_manifest.json. Repacked ZIPs must use the script above. The patch includes the standard IPS final-size extension; the patched ZIP hash must match the manifest.

Test 17 restores the original Gold rival routes and adds Cammy CPU decisions, campaign orders, hit-effect offsets, Psycho Streak projectile collisions, a Hooligan mirror-match correction and source voice envelopes. The isolated blue-trail square reported on Gen's stage remains unconfirmed. See the included build README for provenance and validation limits.
