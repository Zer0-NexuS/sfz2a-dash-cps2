"""Apply one current GOLD IPS patch to a stock sfz2ald.zip; verify every ROM.
Usage: python apply_gold_ips.py VARIANT.ips stock/sfz2ald.zip output/sfz2ald.zip
Keep patch_manifest.json and the members folder beside this script.
"""
from pathlib import Path
import argparse,hashlib,io,json,zipfile
def sha(b):return hashlib.sha256(b).hexdigest()
def apply_ips(source,patch):
    if patch[:5]!=b'PATCH':raise ValueError('Invalid IPS signature')
    out=bytearray(source);p=5
    while True:
        if p+3>len(patch):raise ValueError('Missing IPS EOF')
        off=patch[p:p+3];p+=3
        if off==b'EOF':break
        at=int.from_bytes(off,'big')
        if p+2>len(patch):raise ValueError('Truncated IPS size')
        n=int.from_bytes(patch[p:p+2],'big');p+=2
        if n:
            if p+n>len(patch):raise ValueError('Truncated IPS record')
            data=patch[p:p+n];p+=n
        else:
            if p+3>len(patch):raise ValueError('Truncated RLE record')
            n=int.from_bytes(patch[p:p+2],'big');data=patch[p+2:p+3]*n;p+=3
            if not n:raise ValueError('Empty RLE record')
        if at+n>len(out):out.extend(bytes(at+n-len(out)))
        out[at:at+n]=data
    if len(patch)-p not in (0,3):raise ValueError('Invalid IPS trailer')
    if len(patch)-p==3:
        n=int.from_bytes(patch[p:],'big')
        if len(out)<n:out.extend(bytes(n-len(out)))
        else:del out[n:]
    return bytes(out)
def apply_checked(patch,source,root):
    manifest=json.loads((root/'patch_manifest.json').read_text())
    matches=[x for x in manifest['targets']if x['patch_sha256']==sha(patch)]
    if len(matches)!=1:raise ValueError('Patch does not match this toolkit version')
    target=matches[0]
    if sha(source)==manifest['base_zip_sha256']:
        result=apply_ips(source,patch)
        if sha(result)!=target['output_sha256']:raise ValueError('Output ZIP hash mismatch')
        method='exact archive IPS'
    else:
        with zipfile.ZipFile(io.BytesIO(source))as z:
            if len(set(z.namelist()))!=len(z.namelist()):raise ValueError('Duplicate ZIP members')
            if set(z.namelist())!=set(manifest['base_members_sha256']):raise ValueError('Stock ROM member list differs')
            members={n:z.read(n)for n in z.namelist()}
        for n,h in manifest['base_members_sha256'].items():
            if sha(members[n])!=h:raise ValueError('Wrong stock ROM member: '+n)
        for n,record in target['member_patches'].items():
            mp=(root/record['path']).read_bytes()
            if sha(mp)!=record['sha256']:raise ValueError('Damaged member patch: '+n)
            members[n]=apply_ips(members[n],mp)
        buffer=io.BytesIO()
        with zipfile.ZipFile(buffer,'w')as z:
            for meta in target['zip_metadata']:
                info=zipfile.ZipInfo(meta['name'],tuple(meta['date_time']))
                for key in ('compress_type','external_attr','internal_attr','create_system','create_version','extract_version'):setattr(info,key,meta[key])
                info.extra=bytes.fromhex(meta['extra']);info.comment=bytes.fromhex(meta['comment'])
                z.writestr(info,members[info.filename])
        result=buffer.getvalue();method='verified ROM-member IPS fallback'
    with zipfile.ZipFile(io.BytesIO(result))as z:
        if z.testzip()is not None:raise ValueError('Output ZIP failed integrity check')
        if set(z.namelist())!=set(target['output_members_sha256']):raise ValueError('Output member list differs')
        for n,h in target['output_members_sha256'].items():
            if sha(z.read(n))!=h:raise ValueError('Output member hash mismatch: '+n)
    return result,method
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('patch',type=Path);ap.add_argument('stock_zip',type=Path);ap.add_argument('output_zip',type=Path);a=ap.parse_args()
    if a.output_zip.exists()or a.output_zip.resolve()==a.stock_zip.resolve():raise SystemExit('Choose a new output path; existing files are not overwritten')
    try:result,method=apply_checked(a.patch.read_bytes(),a.stock_zip.read_bytes(),Path(__file__).resolve().parent)
    except (ValueError,OSError,zipfile.BadZipFile)as e:raise SystemExit(str(e))
    a.output_zip.parent.mkdir(parents=True,exist_ok=True)
    with a.output_zip.open('xb')as f:f.write(result)
    print('Verified:',method);print('Saved:',a.output_zip);print('ZIP SHA-256:',sha(result))
if __name__=='__main__':main()
